<?php


// SPAM INFO

$yourname = "DRFXND";

$Email = "ojewire@gmail.com"; 

$Api = "6613413629:AAGrA8g1Sqw-SbbDg8BjCHFC0uf3Yu0ddAY";
$chatid ="6352277850";

// yes / no

$Save_Result = "no";

?>